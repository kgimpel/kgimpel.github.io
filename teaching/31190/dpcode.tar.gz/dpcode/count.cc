#include <iostream>
using namespace std;
int T[31][2];
int f(int s1, int s2) {
	if (s1 == 0 && s2 == 0) return 0;
	return 1;
}
int R(int N, int s) {
	if (T[N][s] != -2) return T[N][s];
	if (N == 1) {
		T[N][s] = 1;
		return T[N][s];
	}
	T[N][s] = R(N-1,0)*f(0,s) + R(N-1,1)*f(1,s);
	return T[N][s];
}
int C(int N) {
	return R(N, 0) + R(N, 1);
}
void resetTable() {
	for (int i = 0; i <= 31; ++i) {
		T[i][0] = -2;
		T[i][1] = -2;
	}
}
int main() {
cerr << "hello " << endl;
for (int i = 1; i <= 31; ++i) {
	resetTable();
	cerr << i << "\t" << C(i) << endl;
}
return 0;
}

