#include <iostream>
using namespace std;
int t[31][2][2];
int f(int prevPrevSymbol, int prevSymbol, int currSymbol) {
	if (prevPrevSymbol == 0 && prevSymbol == 1 && currSymbol == 0) return 0;
	return 1;
}
// Returns number of sequences of length "len" that end in symbol "last".
int R(int len, int secondLast, int last) {
	if (len == 1) {
		if (secondLast != -1) {
			cerr << "Error: length-1 sequence with two symbols provided!" << endl;
			exit(1);
			return -3;
		} else {
			return f(-1, secondLast, last);
		}
	} else if (len == 2) {
		if (t[len][secondLast][last] == -2) {
			t[len][secondLast][last] = f(-1, secondLast, last);;
		}
		return t[len][secondLast][last];
	}
	if (t[len][secondLast][last] == -2) {
		t[len][secondLast][last] = 
			f(0,secondLast,last)*R(len - 1, 0, secondLast) 
			+ f(1,secondLast,last)*R(len - 1, 1, secondLast);
	}
	return t[len][secondLast][last];
}
int C(int N) {
	if (N < 1) return 0;
	if (N == 1) return R(N, -1, 0) + R(N, -1, 1);
	return (R(N,0,0) + R(N,0,1) + R(N,1,0) + R(N,1,1));
}
void resetT(int maxlen) {
	for (int i = 0; i < maxlen; ++i) {
        	t[i][0][0] = -2;
        	t[i][0][1] = -2;
		t[i][1][0] = -2;
		t[i][1][1] = -2;
	}
}

int main() {
for (int i = 0; i < 31; ++i) {
	resetT(i+1);
	cerr << i << "\t" << C(i) << endl;
}
return 0;
}

