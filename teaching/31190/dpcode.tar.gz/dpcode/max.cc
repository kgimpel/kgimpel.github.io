#include <iostream>
using namespace std;
int t[51][2];
int bp[51][2];

int f(int s1, int s2) {
	if (s1 == 0 && s2 == 1) return 1;
	return 0;
}

int R(int len, int s) {
	if (len == 1) {
		if (t[len][s] == -2) {
			t[len][s] = f(-1, s);
			bp[len][s] = -1;
		}
		return t[len][s];
	}
	if (t[len][s] == -2) {
		int c0 = f(0, s) + R(len - 1, 0);
		int c1 = f(1, s) + R(len - 1, 1);
		if (c1 > c0) {
			t[len][s] = c1;
			bp[len][s] = 1;
		} else {
			t[len][s] = c0;
			bp[len][s] = 0;
		}
	}
	return t[len][s];
}
int C(int n, int& finalSymbol) {
	int c0 = R(n, 0);
	int c1 = R(n, 1);
	if (c1 > c0) {
		// set finalSymbol backpointer (it's passed by reference).
		finalSymbol = 1;
		return c1;
	} else {
		finalSymbol = 0;
		return c0;
	}
}
void followBackpointers(int n, int last, string& s) {
	if (n == 0) return;
	string symbolToAdd = "";
	if (last == 0) symbolToAdd = "0";
	if (last == 1) symbolToAdd = "1";
	if (last == -1) symbolToAdd = "<s>";
	s = symbolToAdd + s;
	int prevSymbol = bp[n][last];//bp[n][last]];
	followBackpointers(n-1, prevSymbol, s);
}

void resetT() {
	for (int i = 0; i <= 50; ++i) {
		t[i][0] = -2;
		t[i][1] = -2;
		bp[i][0] = -2;
		bp[i][1] = -2;
	}
}

int main() {
for (int i = 1; i <= 30; ++i) {
	resetT();
	int finalSymbol = -4;
	int maxScore = C(i, finalSymbol);
	string s = "";
	followBackpointers(i, finalSymbol, s);
	cerr << i << "\t" << maxScore << "\t" << s << endl;
}
return 0;
}

