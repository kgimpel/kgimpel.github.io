#include <iostream>
using namespace std;
int t[31][31][2];
int score(int prevSymbol, int currSymbol) {
	//if (prevSymbol == 0 && currSymbol == 0) return 0;
	return 1;
}
// Returns number of sequences of length "len" that end in symbol "last".
int Caux(int len, int numOnes, int last) {
	if (len == 1) {
		if (numOnes == last) return 1;
		return 0;
	}
	if (t[len][numOnes][last] == -2) {
		int indicLastIsOne = 0;
		if (last == 1) indicLastIsOne = 1;
		t[len][numOnes][last] = score(0,last)*Caux(len - 1, numOnes - indicLastIsOne, 0) 
			+ score(1,last)*Caux(len - 1, numOnes - indicLastIsOne, 1);
	}
	return t[len][numOnes][last];
}
int C(int len) {
	if (len < 3) return 0;
	int s = 0;
	for (int i = 3; i <= len; ++i) {
		s += (Caux(len, i, 0) + Caux(len, i, 1));
	}
	return s;
	//return Caux(len, 0) + Caux(len, 1);
}
void resetT(int maxlen) {
	for (int i = 0; i < maxlen; ++i) {
        	for (int j = 0; j < maxlen; ++j) {
			t[i][j][0] = -2;
        		t[i][j][1] = -2;
		}
	}
}

int main() {
int N = 30;
for (int i = 0; i <= N; ++i) {
	resetT(i+1);
	cerr << i << "\t" << C(i) << endl;
}
return 0;
}

