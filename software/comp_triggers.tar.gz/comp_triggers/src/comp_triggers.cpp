//
// File:   comp_triggers.cpp
// Author: Kevin Gimpel
//
// Created on Feb 15, 2011
//
#include <stdlib.h>
#include "comp_triggers.h"

const double neg_inf = log(0.0);
const double pos_inf = -neg_inf;

// Returns log(exp(lx) + exp(ly)).
double logAdd(const double lx, const double ly) {
	if (lx == neg_inf) return ly;
	if (ly == neg_inf) return lx;
	double d = lx - ly;
	if (d >= 0) {
		if (d > 50) {
			return lx;
		} else {
			return (double)(lx + log(1.0 + exp(-d)));
		}
	} else {
		if (d < -50) {
			return ly;
		} else {
			return (double)(ly + log(1.0 + exp(d)));
		}
	}
}

// Returns log(exp(lx) - exp(ly)).
double logSubtract(const double lx, const double ly) {
	if (lx == ly) {
		return neg_inf;
	} else if (lx > ly) {
		return (double)(lx + log(1.0 - exp(ly - lx)));
	} else {
		return (double)(ly + log(1.0 - exp(lx - ly)));
	}
}

void tokenize(const string& str, char delimiter, vector<string>& tokens) {
	// Skip delimiters at beginning. Find first "non-delimiter".
   	string::size_type lastPos = str.find_first_not_of(delimiter, 0);
	// Find next instance of the delimiter.
   	string::size_type pos = str.find_first_of(delimiter, lastPos);

   	while (string::npos != pos || string::npos != lastPos) {
       	// Add the token from lastPos to pos.
       	tokens.push_back(str.substr(lastPos, pos - lastPos));

       	// Find the start of the next token.
       	lastPos = str.find_first_not_of(delimiter, pos);

       	// Find the end of the token.
       	pos = str.find_first_of(delimiter, lastPos);
   	}
}

int main(int argc, char** argv) {
    ParamsArray params(argc, argv);
    params.setDescription("compute trigger word pairs using Rosenfeld's method based on mutual information");
    params.addConstraint("input_file", "file containing tokenized input text, one sentence per line", false); // not optional
    params.addConstraint("output_file", "file in which to output trigger word pairs", false); // not optional
    params.addConstraint("min_gap_width", "minimum width of gap (in number of words) "
		"between words in each trigger pair (default: 1)", true); // optional
    params.addConstraint("min_mi", "minimum mutual information of trigger pairs to print; if 0.0, will print all (default: 0.0)", true); // optional

   	if (!params.runConstraints("comp_triggers")) return 0;

	// Read in command-line parameters.
	string inputFilename = params.asString("input_file");
	string outputFilename = params.asString("output_file");
	int offset = atoi(params.asString("min_gap_width", "1").c_str());
	double minMutualInformation = atof(params.asString("min_mi", "0.0").c_str());
	if (offset < 0) {
		cerr << "Minimum gap width must be >= 0. You passed in " << offset << ". Using zero instead..." << endl;
		offset = 0;
	}

	clock_t clock1, clock2, clock3, clock4;
	clock1 = clock();

	// First try to open the input and output files. Exit if there was a problem.
    ifstream inputFile(inputFilename.c_str());
    if (!inputFile) {
   	    cerr << "Cannot open input file " << inputFilename << ". Exiting..." << endl;
   	    return 1;
	}
    ofstream outputFile(outputFilename.c_str());
    if (!outputFile) {
   	    cerr << "Cannot open output file " << outputFilename << ". Exiting..." << endl;
   	    return 1;
	}

	// Count of all tokens observed.
	int totalSoloCount = 0;
	// Count of all word pairs observed, with distance .
	int totalPairCount = 0;

	// We store counts in maps from strings to integer counts.
	// Holds raw counts of trigger pairs.
	map<pair<string, string>, int> pairCounts;
	// The following maps hold counts of all words that appear first (in soloCounts1) 
	// or second (in soloCounts2) in a trigger pair.
	map<string, int> soloCounts1, soloCounts2;

	cerr << "Reading input file and computing counts." << endl;
	string line;
	int curr = 0;
	// Go through all lines in the input file.
    while (!inputFile.eof()) {
	    getline(inputFile, line);
	    if (line != "") {
			++curr;
			if (curr % 2000 == 0) {
				cerr << ".";
				if (curr % 20000 == 0) {
					clock2 = clock();
					double partialTime = (((double)(clock2 - clock1)) / ((double)(CLOCKS_PER_SEC)));
					cerr << " processed " << curr << " lines (" << partialTime << " sec) " << endl;
				}
			}

			// Tokenize the line.
			vector<string> tokens;
			tokenize(line, ' ', tokens);
			// Add the total number of tokens in the line to our token count.
			totalSoloCount += tokens.size();
			// Go through all tokens and increment the unigram and pair counts.
			for (unsigned int i = 0; i < tokens.size(); ++i) {
				for (unsigned int j = i + offset + 1; j < tokens.size(); ++j) {
					soloCounts1[tokens[i]] += 1;
					soloCounts2[tokens[j]] += 1;
					pairCounts[make_pair(tokens[i], tokens[j])] += 1;
					++totalPairCount;
				}
			}
		}
	}
	inputFile.close();
	clock2 = clock();
	double readInputTime = (((double)(clock2 - clock1)) / ((double)(CLOCKS_PER_SEC)));
	cerr << "Done (" << readInputTime << " sec)" << endl << endl;
	cerr << "Now computing mutual information and writing trigger pairs to output file." << endl;

	clock4 = clock();

	double logTotalPairCount = log((double) totalPairCount);
	// Go through all pair counts that are nonzero.
	map<pair<string, string>, int>::iterator pairCountIter;
	curr = 0;
	int numPrinted = 0;
	double numPairs = (double) (pairCounts.size());
	for (pairCountIter = pairCounts.begin(); pairCountIter != pairCounts.end(); ++pairCountIter) {
		// Compute the mutual information between the two words in the pair.
		const string& word1 = pairCountIter->first.first;
		const string& word2 = pairCountIter->first.second;
		double logCount1 = log((double) soloCounts1[word1]);
		double logCount2 = log((double) soloCounts2[word2]);
		int pairCount = pairCountIter->second;
		double logPairCount = log((double)pairCount);
		double logCount1And2Inverse = logSubtract(logCount1, logPairCount);
		double logCount1InverseAnd2 = logSubtract(logCount2, logPairCount);
		double logCount1Inverse = logSubtract(logTotalPairCount, logCount1);
		double logCount2Inverse = logSubtract(logTotalPairCount, logCount2);
		double logCount1InverseAnd2Inverse = logSubtract(logSubtract(logAdd(logTotalPairCount, logPairCount), logCount1), logCount2);
		if (logPairCount != logPairCount) cerr << "Warning: logPairCount = " << logPairCount << endl;
		if (logCount1Inverse != logCount1Inverse) cerr << "Warning: logCount1Inverse = " << logCount1Inverse << endl;
		if (logCount2Inverse != logCount2Inverse) cerr << "Warning: logCount2Inverse = " << logCount2Inverse << endl;
		if (logCount1And2Inverse != logCount1And2Inverse) cerr << "Warning: logCount1And2Inverse = " << logCount1And2Inverse << endl;
		if (logCount1InverseAnd2 != logCount1InverseAnd2) cerr << "Warning: logCount1InverseAnd2 = " << logCount1InverseAnd2 << endl;
		if (logCount1InverseAnd2Inverse != logCount1InverseAnd2Inverse) 
			cerr << "Warning: logCount1InverseAnd2Inverse = " << logCount1InverseAnd2Inverse << endl;

		double term1 = exp(logPairCount - logTotalPairCount);
		double term1LogPart = logPairCount + logTotalPairCount - (logCount1 + logCount2);
		term1 *= term1LogPart;

		// We have to explicitly check for neg_inf below to avoid nans since neg_inf * 0.0 = nan.
		double term2 = 0.0;
		if (logCount1And2Inverse != neg_inf) {
			term2 = exp(logCount1And2Inverse - logTotalPairCount);
			double term2LogPart = logCount1And2Inverse + logTotalPairCount - (logCount1 + logCount2Inverse);
			term2 *= term2LogPart;
		}

		double term3 = 0.0;
		if (logCount1InverseAnd2 != neg_inf) {
			term3 = exp(logCount1InverseAnd2 - logTotalPairCount);
			double term3LogPart = logCount1InverseAnd2 + logTotalPairCount - (logCount1Inverse + logCount2);
			term3 *= term3LogPart;
		}

		double term4 = exp(logCount1InverseAnd2Inverse - logTotalPairCount);
		double term4LogPart = logCount1InverseAnd2Inverse + logTotalPairCount - (logCount1Inverse + logCount2Inverse);
		term4 *= term4LogPart;

		double mutualInformation = term1 + term2 + term3 + term4;
		// If it dropped below 0.0, it did so because of floating point precision, so reset it to 0.0.
		if (mutualInformation < 0.0) mutualInformation = 0.0;
		if (mutualInformation >= minMutualInformation) {
			outputFile << mutualInformation << "\t" << word1 << "\t" << word2 << endl;
			++numPrinted;
		}
		++curr;
		if (curr % 50000 == 0) {
			cerr << ".";
			if (curr % 1000000 == 0) {
				clock2 = clock();
				double partialTime = (((double)(clock2 - clock4)) / ((double)(CLOCKS_PER_SEC)));
				cerr << " processed " << curr << " pairs, printed " << numPrinted << "; " 
					 << 100.0 * (((double)curr) / numPairs) << "% done (" << partialTime << " sec) " << endl;
			}
		}
	}
	outputFile.close();

	clock3 = clock();
	double printingTime = (((double)(clock3 - clock4)) / ((double)(CLOCKS_PER_SEC)));
	cerr << "100.00% done (" << printingTime << " sec)" << endl;

	double totalTime = (((double)(clock3 - clock1)) / ((double)(CLOCKS_PER_SEC)));
	cerr << "Total time: " << totalTime << " sec" << endl;

    return 0;
}
