#ifndef COMP_TRIGGERS_H_
#define COMP_TRIGGERS_H_

#include <fstream>
#include <iostream>
#include <vector>
#include <map>
#include <math.h>
#include <time.h>
#include "cmdparams.h"

using namespace std;

extern const double neg_inf;
extern const double pos_inf;

#endif
