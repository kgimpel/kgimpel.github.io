#!/bin/sh
./comp_triggers \
input_file=sample/news_commentary.txt \
output_file=sample/triggers.txt \
min_gap_width=1 min_mi=1.5e-5 2> sample/sample_run.log
